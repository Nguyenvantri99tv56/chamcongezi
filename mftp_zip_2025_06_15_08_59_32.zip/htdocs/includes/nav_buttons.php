<div class="nav-buttons" style="margin-bottom: 20px;">
  <button onclick="window.location.href='../dashboard.php'" style="margin-right:10px; padding:8px 16px;">Trang Chủ</button>
  <button onclick="history.back()" style="padding:8px 16px;">Quay Lại</button>
</div>
