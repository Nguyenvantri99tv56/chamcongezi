<?php
// config.php - cấu hình kết nối database

define('DB_HOST', 'sql307.infinityfree.com');      // Host MySQL (thường là localhost hoặc server bạn dùng)
define('DB_USER', 'if0_37824703');                  // Tên user database
define('DB_PASS', 'Dmx123457');                      // Mật khẩu database
define('DB_NAME', 'if0_37824703_ezicore');          // Tên database

// Bạn có thể thêm các cấu hình khác ở đây nếu cần
