<?php
echo "Test page is working!";
?>
